(function ($) {
"use strict";

    var AhopeGlobal = function ($scope, $) {

        // Js Start
            $('[data-background]').each(function() {
                $(this).css('background-image', 'url('+ $(this).attr('data-background') + ')');
            });
        $(".preloader").fadeOut();
        if($('.wow').length){
            new WOW({
                offset: 100,
                mobile: true
            }).init()
        }
        jQuery(window).on('scroll', function() {
            if (jQuery(window).scrollTop() > 250) {
                jQuery('.ahope-sticky-header').addClass('sticky-on')
            } else {
                jQuery('.ahope-sticky-header').removeClass('sticky-on')
            }
        });
        $(".ahope-icon-lightbox a").magnificPopup({
            type: 'iframe',
            iframe: {
                patterns: {
                    youtube: {
                        index: 'youtube.com/',
                        id: 'v=',
                        src: 'https://www.youtube.com/embed/%id%?autoplay=1'
                    },
                    vimeo: {
                        index: 'vimeo.com/',
                        id: '/',
                        src: '//player.vimeo.com/video/%id%?autoplay=1'
                    },
                    gmaps: {
                        index: '//maps.google.',
                        src: '%id%&output=embed'
                    }
                },
                srcAction: 'iframe_src',
            }
        });
        // Js End

    };

    var CDNavMenu = function ($scope, $) {

        $scope.find('.ahope-nav-builder').each(function () {
            var settings = $(this).data('ahope');

        // Js Start
            $('.str-open_mobile_menu').on("click", function() {
                $('.str-mobile_menu_wrap').toggleClass("mobile_menu_on");
            });
            $('.str-open_mobile_menu').on('click', function () {
                $('body').toggleClass('mobile_menu_overlay_on');
            });
            if($('.str-mobile_menu li.dropdown ul').length){
                $('.str-mobile_menu li.dropdown').append('<div class="dropdown-btn"><span class="fa fa-angle-down"></span></div>');
                $('.str-mobile_menu li.dropdown .dropdown-btn').on('click', function() {
                    $(this).prev('ul').slideToggle(500);
                });
            }
        // Js End
        });

    };
    var AhopeTesti = function ($scope, $) {

        $scope.find('.testimonial_area').each(function () {
            var settings = $(this).data('ahope');

        // Js Start
            var mySwiper = new Swiper ('.testimonial_wrapper.swiper-container', {
                direction: 'horizontal',
                slidesPerView: settings['item'],
                loop: true,
                centeredSlides: true,
                autoplay: {
                    delay: 2000,
                    disableOnInteraction: false,
                },
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                breakpoints: {
                    992: {
                        slidesPerView: settings['item'],
                        spaceBetween: 40,
                        centeredSlides: false,
                    },
                    768: {
                        slidesPerView: 1,
                        spaceBetween: 30,
                    }
                }

            });
        });
            $scope.find('.testimonial_2').each(function () {
                var settings = $(this).data('ahope');

            var mySwiper = new Swiper ('.testimonial_area_4', {
                direction: 'horizontal',
                slidesPerView: settings['item'],
                effect: 'fade',
                speed: 900,
                fadeEffect: {
                    crossFade: true
                },
                spaceBetween: 30,
                loop: true,
                centeredSlides: false,
                autoplay: {
                    delay: 2500,
                    disableOnInteraction: false,
                },
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                }

                });
            });
        // Js End

    };
    var AhopeBlog = function ($scope, $) {

        $scope.find('.blog_area_2').each(function () {
            var settings = $(this).data('ahope');

        // Js Start
            var mySwiper = new Swiper ('.blog_carousel.swiper-container', {
                direction: 'horizontal',
                slidesPerView: settings['item'],
                loop: true,
                centeredSlides: false,
                //  autoplay: {
                //   delay: 2000,
                //   disableOnInteraction: false,
                // },
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                breakpoints: {
                    992: {
                        slidesPerView: settings['item'],
                        centeredSlides: false,
                    },
                    768: {
                        slidesPerView: 1,
                        centeredSlides: false,
                    }
                }

            });
        // Js End
        });

    };

    var Features2 = function ($scope, $) {

        $scope.find('.service_carousel_area_2').each(function () {
            var settings = $(this).data('ahope');

        // Js Start
            var mySwiper = new Swiper ('.service_carousel', {
                direction: 'horizontal',
                slidesPerView: settings['item'],
                loop: true,
                centeredSlides: false,
                autoplay: {
                    delay: 2000,
                    disableOnInteraction: false,
                },
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                breakpoints: {
                    992: {
                        slidesPerView: settings['item'],
                        centeredSlides: false,
                    },
                    768: {
                        slidesPerView: 1,
                        centeredSlides: false,
                    }
                }

            });
        // Js End
        });

    };


    $(window).on('elementor/frontend/init', function () {
        if (elementorFrontend.isEditMode()) {
            console.log('Elementor editor mod loaded');
            elementorFrontend.hooks.addAction('frontend/element_ready/global', AhopeGlobal);
            elementorFrontend.hooks.addAction('frontend/element_ready/nav-builder.default', CDNavMenu);
            elementorFrontend.hooks.addAction('frontend/element_ready/ahope-testimonial.default', AhopeTesti);
            elementorFrontend.hooks.addAction('frontend/element_ready/ahope-blog.default', AhopeBlog);
            elementorFrontend.hooks.addAction('frontend/element_ready/ahope-whybest.default', Features2);
        }
        else {
            console.log('Elementor frontend mod loaded');
            elementorFrontend.hooks.addAction('frontend/element_ready/global', AhopeGlobal);
            elementorFrontend.hooks.addAction('frontend/element_ready/ahope-testimonial.default', AhopeTesti);
            elementorFrontend.hooks.addAction('frontend/element_ready/ahope-blog.default', AhopeBlog);
            elementorFrontend.hooks.addAction('frontend/element_ready/ahope-whybest.default', Features2);
        }
    });
console.log('addon js loaded');
})(jQuery);