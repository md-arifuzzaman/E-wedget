<?php

namespace Elementor;
use AhopeElement_Elementor_Addons;
if (!defined('ABSPATH')) exit; // Exit if accessed directly

class pricing_table extends Widget_Base
{

    public function get_name()
    {
        return 'pricing-table';
    }

    public function get_title()
    {
        return __('Pricing Table', 'ahope');
    }

    public function get_categories()
    {
        return ['ahopeelement-addons'];
    }

    public function get_icon()
    {
        return 'eicon-sitemap';
    }

    public function render_plain_content($instance = [])
    {
    }

    protected function _register_controls()
    {


        $this->start_controls_section(
            'pm',
            [
                'label' => __('Monthly', 'ahope'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'grid',
            [
                'label' => __('Grid Item', 'ahope'),
                'type' => Controls_Manager::NUMBER,
                'default' => __('3', 'ahope'),
            ]
        );
        $repeater = new Repeater();
        $repeater->add_control(
            'title',
            [
                'label' => __('Title', 'ahope'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Basic', 'ahope'),
            ]
        );
        $repeater->add_control(
            'sub',
            [
                'label' => __('Sub Title', 'ahope'),
                'type' => Controls_Manager::TEXT,
                'default' => __('month', 'ahope'),
            ]
        );
        $repeater->add_control(
            'price',
            [
                'label' => __('Price', 'ahope'),
                'type' => Controls_Manager::NUMBER,
                'default' => __('29', 'ahope'),
            ]
        );
        $repeater->add_control(
            'unit',
            [
                'label' => __('Unit', 'ahope'),
                'type' => Controls_Manager::TEXT,
                'default' => __('$', 'ahope'),
            ]
        );
        $repeater->add_control(
            'features',
            [
                'label' => __('Features', 'ahope'),
                'type' => AhopeElement_Elementor_Addons::LIST_CONTROL,
            ]
        );
        $repeater->add_control(
            'button',
            [
                'label' => __('Button', 'ahope'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Start Now', 'ahope'),
            ]
        );
        $repeater->add_control(
            'link', [
                'label' => __('Link', 'ahope'),
                'type' => Controls_Manager::URL,
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                ],
            ]
        );
        $repeater->add_control(
            'photo', [
                'label' => __('Photo', 'ahope'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'price_list',
            [
                'label' => __('Pricing Table', 'ahope'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'title' => 'Primary Plan',
                    ],
                    [
                        'title' => 'Basic Plan',
                    ],
                    [
                        'title' => 'Premium Plan',
                    ],

                ],
                'title_field' => '{{{ title }}}',
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Style', 'ahope'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'ahope'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-head .price-ribbon-title' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_fonts',
                'label' => __('Title Typography', 'ahope'),
                'selector' => '{{WRAPPER}} .price-box .price-head .price-ribbon-title',
            ]
        );
        $this->add_control(
            'pricing_color',
            [
                'label' => __('Pricing Color', 'ahope'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-head .price-value h4' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'pr_fonts',
                'label' => __('Pricing Typography', 'ahope'),
                'selector' => '{{WRAPPER}} .price-box .price-head .price-value h4',
            ]
        );
        $this->add_control(
            'unit_color',
            [
                'label' => __('Unit Color', 'ahope'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-head .price-value h4 span' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'pruu_fonts',
                'label' => __('Unit Typography', 'ahope'),
                'selector' => '{{WRAPPER}} .price-box .price-head .price-value h4 span',
            ]
        );
        $this->add_control(
            'fe_color',
            [
                'label' => __('Feature Color', 'ahope'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-info ul li' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'fea_fonts',
                'label' => __('Feature Typography', 'ahope'),
                'selector' => '{{WRAPPER}} .price-box .price-info ul li',
            ]
        );
        $this->add_control(
            'btn_color',
            [
                'label' => __('Button Color', 'ahope'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-bottom .btn-6' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'btn_bg_color',
            [
                'label' => __('Button BG Color', 'ahope'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-bottom .btn-6' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'btn_hover_color',
            [
                'label' => __('Button Hover Color', 'ahope'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-bottom .btn-6:before' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        echo '<!-- Start Price
		============================================= -->
        <div class="price-area">
                <div class="price-wpr grid-'.$settings['grid'].'">';

        if ($settings['price_list']) {

            foreach ($settings['price_list'] as $monthly) {

                echo '<div class="price-box wow fadeInLeft">
                        <div class="price-head">
                            <div class="price-image">
							    '.get_that_image($monthly['photo']).'
							</div>
                            <div class="price-rib">
                                <span class="price-ribbon-title">' . $monthly['title'] . '</span>
                            </div>
                            <div class="price-value">
                                <h4><span>' . $monthly['unit'] . '</span>' . $monthly['price'] . '<span>/' . $monthly['sub'] . '</span></h4>
                            </div>
                        </div>
                        <div class="price-info">
                            <ul>';
                                ahope_list_control($monthly['features'], '<i class="fas fa-check-circle"></i>');
                            echo'</ul>
                        </div>
                        <div class="price-bottom">
                            <a ' . get_that_link($monthly['link']) . ' class="btn-6">' . $monthly['button'] . '</a>
                        </div>
                    </div>';

            }
        }
        echo '</div>
        </div>
        <!-- End Price -->'; ?>
        <!-- Start Packege-Pricing Section -->
        <section class="packege_pricing_area_6">
            <div class="container">

                <div class="row">
                    <div class="col-md-4 offset-md-4 col-lg-3 offset-lg-0 ">
                        <div class="pricing_tabling d-flex flex-column justify-content-center align-items-center">
                            <div class="select_month_wrapper">
                                <input type="text" id="chose_plan" readonly>
                                <span class="arrow" ></span>
                                <span class="split" ></span>
                                <ol class="option_list">
                                    <li value="1" id="firstItem_plan">Monthly Plan</li>
                                    <li value="2">Yearly Plan</li>
                                </ol>
                            </div>
                            <h3>Pricing Package</h3>
                        </div>
                    </div>
                </div>

            </div>
            <div class="container tab_wrapper">
                <div class="row tab_1">
                    <div class="col-sm-12 col-md-4 col-lg-3 d-none d-lg-block">
                        <div class="single_pakege_6 item_list">
                            <div class="pricing_top"></div>
                            <ul class="pakege_service_list">
                                <li>Storage</li>
                                <li>Bandwith</li>
                                <li>VPSt</li>
                                <li>SSL</li>
                                <li>24/7 Live Support</li>
                                <li>Domain</li>
                                <li>Free Domain</li>
                                <li>Database</li>
                                <li>cPanel</li>
                                <li>CLI & API</li>
                                <li>DNS</li>
                            </ul>
                            <div class="pricing_footer"></div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-3">
                        <div class="single_pakege_6 regular">
                            <div class="pricing_top d-flex justify-content-center flex-column align-items-center">
                                <p class="plan_titel">Regular</p>
                                <h2 class="price">$27</h2>
                            </div>
                            <ul class="pakege_service_list">
                                <li><span class="d-inline-block d-md-block d-lg-none">Storage</span>1 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Bandwith</span>10 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">VPS</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">SSL</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">24/7 Live Support</span><i class="ti-check unchecked"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Domain</span> 5 Domain</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Free Domain</span><i class="ti-check unchecked"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Database</span>Single</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">cPanel</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">CLI & API</span><i class="ti-check unchecked"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">DNS</span><i class="ti-check unchecked"></i></li>
                            </ul>
                            <div class="pricing_footer">
                                <a href="#" class="boxed_btn"><span>Get It</span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-3">
                        <div class="single_pakege_6 advance">
                            <div class="pricing_top d-flex justify-content-center flex-column align-items-center">
                                <p class="plan_titel">Regular</p>
                                <h2 class="price">$37</h2>
                            </div>
                            <ul class="pakege_service_list">
                                <li><span class="d-inline-block d-md-block d-lg-none">Storage</span>5 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Bandwith</span>50 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">VPS</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">SSL</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">24/7 Live Support</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Domain</span> 10 Domain</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Free Domain</span><i class="ti-check unchecked"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Database</span>Unlimited</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">cPanel</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">CLI & API</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">DNS</span><i class="ti-check"></i></li>
                            </ul>
                            <div class="pricing_footer">
                                <a href="#" class="boxed_btn"><span>Get It</span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-3">
                        <div class="single_pakege_6 pro">
                            <div class="pricing_top d-flex justify-content-center flex-column align-items-center">
                                <p class="plan_titel">Regular</p>
                                <h2 class="price">$47</h2>
                            </div>
                            <ul class="pakege_service_list">
                                <li><span class="d-inline-block d-md-block d-lg-none">Storage</span>15 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Bandwith</span>120 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">VPS</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">SSL</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">24/7 Live Support</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Domain</span>Unlimited</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Free Domain</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Database</span>Unlimited</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">cPanel</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">CLI & API</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">DNS</span><i class="ti-check"></i></li>
                            </ul>
                            <div class="pricing_footer">
                                <a href="#" class="boxed_btn"><span>Get It</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row tab_2">
                    <div class="col-sm-12 col-md-4 col-lg-3 d-none d-lg-block">
                        <div class="single_pakege_6 item_list">
                            <div class="pricing_top">
                            </div>
                            <ul class="pakege_service_list">
                                <li>Storage</li>
                                <li>Bandwith</li>
                                <li>VPSt</li>
                                <li>SSL</li>
                                <li>24/7 Live Support</li>
                                <li>Domain</li>
                                <li>Free Domain</li>
                                <li>Database</li>
                                <li>cPanel</li>
                                <li>CLI & API</li>
                                <li>DNS</li>
                            </ul>
                            <div class="pricing_footer">
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-3">
                        <div class="single_pakege_6 regular">
                            <div class="pricing_top d-flex justify-content-center flex-column align-items-center">
                                <p class="plan_titel">Regular</p>
                                <h2 class="price">$55</h2>
                            </div>
                            <ul class="pakege_service_list">
                                <li><span class="d-inline-block d-md-block d-lg-none">Storage</span>1 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Bandwith</span>10 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">VPS</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">SSL</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">24/7 Live Support</span><i class="ti-check unchecked"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Domain</span> 5 Domain</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Free Domain</span><i class="ti-check unchecked"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Database</span>Single</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">cPanel</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">CLI & API</span><i class="ti-check unchecked"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">DNS</span><i class="ti-check unchecked"></i></li>
                            </ul>
                            <div class="pricing_footer">
                                <a href="#" class="boxed_btn"><span>Get It</span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-3">
                        <div class="single_pakege_6 advance">
                            <div class="pricing_top d-flex justify-content-center flex-column align-items-center">
                                <p class="plan_titel">Regular</p>
                                <h2 class="price">$75</h2>
                            </div>
                            <ul class="pakege_service_list">
                                <li><span class="d-inline-block d-md-block d-lg-none">Storage</span>5 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Bandwith</span>50 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">VPS</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">SSL</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">24/7 Live Support</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Domain</span> 10 Domain</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Free Domain</span><i class="ti-check unchecked"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Database</span>Unlimited</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">cPanel</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">CLI & API</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">DNS</span><i class="ti-check"></i></li>
                            </ul>
                            <div class="pricing_footer">
                                <a href="#" class="boxed_btn"><span>Get It</span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-3">
                        <div class="single_pakege_6 pro">
                            <div class="pricing_top d-flex justify-content-center flex-column align-items-center">
                                <p class="plan_titel">Regular</p>
                                <h2 class="price">$97</h2>
                            </div>
                            <ul class="pakege_service_list">
                                <li><span class="d-inline-block d-md-block d-lg-none">Storage</span>15 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Bandwith</span>120 GB</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">VPS</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">SSL</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">24/7 Live Support</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Domain</span>Unlimited</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Free Domain</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">Database</span>Unlimited</li>
                                <li><span class="d-inline-block d-md-block d-lg-none">cPanel</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">CLI & API</span><i class="ti-check"></i></li>
                                <li><span class="d-inline-block d-md-block d-lg-none">DNS</span><i class="ti-check"></i></li>
                            </ul>
                            <div class="pricing_footer">
                                <a href="#" class="boxed_btn"><span>Get It</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End packege-Pricing Section -->
<?php    }


    protected function content_template()
    {
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new pricing_table());
?>